import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash  

app = Flask(__name__)
app.secret_key = 'ce7759a632b72236a7ce365b9ee5353d89a6172c42195b3b'  
# Database connection
conn = sqlite3.connect('database.db', check_same_thread=False)
c = conn.cursor()

# Create users table if not exists
c.execute('''CREATE TABLE IF NOT EXISTS users (
             id INTEGER PRIMARY KEY,
             username TEXT UNIQUE,
             password TEXT
             )''')
conn.commit()

# Create products table if not exists
c.execute('''CREATE TABLE IF NOT EXISTS products (
             id INTEGER PRIMARY KEY,
             name TEXT,
             price REAL,
             for_sale BOOLEAN,
             image TEXT
             )''')
conn.commit()

# Check if 'image' column exists in 'products' table
c.execute("PRAGMA table_info(products)")
columns = c.fetchall()
image_column_exists = any('image' in column for column in columns)

# If 'image' column does not exist, add it to the 'products' table
if not image_column_exists:
    c.execute("ALTER TABLE products ADD COLUMN image TEXT")
    conn.commit()


# Function to insert sample books into the database
def insert_sample_books():
    books = [
        ("Book 1", 10.99, True, "book1.jpg"),
        ("Book 2", 15.99, True, "book2.jpg"),
        ("Book 3", 12.99, True, "book3.jpg"),
        ("Book 4", 10.99, True, "book1.jpg"),
        ("Book 5", 15.99, True, "book2.jpg"),
        ("Book 6", 12.99, True, "book3.jpg"),
        ("Book 7", 10.99, True, "book1.jpg"),
        ("Book 8", 15.99, True, "book2.jpg"),
        ("Book 9", 12.99, True, "book3.jpg"),
        ("Book 10", 12.99, True, "book3.jpg"),
        ("Book 11", 10.99, True, "book1.jpg"),
        ("Book 12", 15.99, True, "book2.jpg"),
        ("Book 13", 12.99, True, "book3.jpg"),
        ("Book 14", 10.99, True, "book1.jpg"),
        ("Book 15", 15.99, True, "book2.jpg"),
        ("Book 16", 12.99, True, "book3.jpg"),
        ("Book 17", 10.99, True, "book1.jpg"),
        ("Book 18", 15.99, True, "book2.jpg"),
        ("Book 19", 12.99, True, "book3.jpg"),
        ("Book 20", 12.99, True, "book3.jpg")
        # Add more books here with their respective image file names
    ]
    c.executemany("INSERT INTO products (name, price, for_sale, image) VALUES (?, ?, ?, ?)", books)
    conn.commit()

# Call the insert_sample_books function before running the app
insert_sample_books()

# Function to hash a password
def hash_password(password):
    return generate_password_hash(password)

# Function to verify a password against its hash
def verify_password(password, hash):
    return check_password_hash(hash, password)

# Function to check if a password is strong
def is_strong_password(password):
    # Implement your strong password validation logic here
    # For example, you can check for minimum length, presence of uppercase, lowercase, digits, and special characters
    return len(password) >= 8 and any(c.islower() for c in password) and any(c.isupper() for c in password) and any(c.isdigit() for c in password)

# Index route
@app.route('/')
def index():
    return render_template('index.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        user = c.fetchone()
        if user and verify_password(password, user[2]):
            flash('Login successful', 'success')
            return redirect(url_for('buy_sell'))  # Redirect to buy_sell upon successful login
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html')


# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if is_strong_password(password):
            hashed_password = hash_password(password)
            c.execute("SELECT * FROM users WHERE username=?", (username,))
            existing_user = c.fetchone()
            if existing_user:
                flash('Username already exists. Please choose a different username.', 'danger')
            else:
                c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
                conn.commit()
                flash('Registration successful', 'success')
                return redirect(url_for('login'))
        else:
            flash('Please use a stronger password.', 'danger')
    
    return render_template('register.html')

# Change password route
@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if request.method == 'POST':
        username = request.form['username']
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        user = c.fetchone()
        if user and verify_password(old_password, user[2]) and is_strong_password(new_password):
            hashed_new_password = hash_password(new_password)
            c.execute("UPDATE users SET password=? WHERE username=?", (hashed_new_password, username))
            conn.commit()
            flash('Password changed successfully', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    return render_template('change_password.html')

# Input field route
@app.route('/input_field', methods=['GET', 'POST'])
def input_field():
    if request.method == 'POST':
        return redirect(url_for('feedback_thanks'))  # Redirect to feedback_thanks upon successful submission
    return render_template('input_field.html')

# Feedback thanks route
@app.route('/feedback_thanks')
def feedback_thanks():
    return render_template('feedback_thanks.html')

# Buy/sell products route
@app.route('/buy_sell', methods=['GET', 'POST'])
def buy_sell():
    if request.method == 'POST':
        # Process buy/sell product data here
        flash('Product bought/sold successfully', 'success')
    # Fetch products from database and pass them to template
    c.execute("SELECT name, price, for_sale, image FROM products WHERE for_sale=True")
    products = c.fetchall()
    products = [{'name': row[0], 'price': row[1], 'for_sale': row[2], 'image': row[3]} for row in products]
    return render_template('buy_sell.html', products=products)

if __name__ == '__main__':
    app.run(debug=True)
